# Windows Style PC Launcher — phone-only APK build

This project can be built from a phone using GitHub Actions (the build runs in GitHub's cloud; Android Studio and Termux are not required on your phone).

## Phone-only steps

1. Extract this ZIP on your phone using its Files app.
2. In a browser, sign in to GitHub and create a **new private repository**.
3. Open the repository and choose **Add file → Upload files**.
4. Upload the *contents* of the `WindowsStylePCLauncher-PhoneBuild` folder, including the hidden `.github` folder if your file picker shows hidden folders. The repository root must contain `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, and `.github`.
5. Commit the upload to the `main` branch.
6. Open the repository's **Actions** tab. If GitHub asks to enable Actions, enable it.
7. Choose **Build Android APK** on the left, tap **Run workflow**, select `main`, and tap **Run workflow** again.
8. Open the new run. Wait until it shows a green check. Open the run, scroll to **Artifacts**, and download `Windows-Style-Launcher-debug`.
9. Extract the downloaded artifact ZIP. It contains `app-debug.apk`.
10. Tap `app-debug.apk` and follow Android's install prompt. Only allow installation from the browser/file manager you used if Android asks.

## If upload on mobile hides .github

The `.github` folder may be hidden by some file pickers. Use the browser's desktop-site option or a file manager that can show hidden files. Confirm `.github/workflows/android-apk.yml` is present in the repository before running Actions.

## Project build settings

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9 (provided by the cloud workflow)
- Java: 17
- compileSdk: 35
- minSdk: 26 (Android 8.0)

## Important

- This creates a **debug APK** for testing, not a Play Store release.
- A successful build means the APK compiled; it does not prove every feature works on every phone.
- The launcher does not replace Android or turn the phone into Windows. Android still controls system permissions and protected settings.
- Keep the repository private if you do not want the source code to be public. Never upload passwords, signing keys, or private tokens.
