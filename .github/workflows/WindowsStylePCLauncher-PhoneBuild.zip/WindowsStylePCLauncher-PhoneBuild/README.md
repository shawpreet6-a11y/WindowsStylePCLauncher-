# Windows Style PC Launcher (Android)

A Windows-inspired Android home launcher built with a WebView interface and a small native Kotlin bridge. It does **not** contain AI features.

## Included
- Windows-style desktop, Start menu, taskbar, quick panel and window UI
- Lists installed apps that expose a launcher activity and opens them
- Opens Android Wi-Fi, Bluetooth and system Settings pages
- Opens Android's system document picker for phone files
- Landscape/portrait responsive layout
- Android HOME launcher intent filter (choose it as the Home app in Android settings)

## Build an APK
1. Open this folder in Android Studio (Hedgehog or newer recommended).
2. Install Android SDK Platform 35 and a compatible Android Gradle Plugin toolchain if prompted.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the generated debug APK on your Android phone.

## Important limitations
- This is a launcher app, not Windows and not a replacement operating system.
- Android controls protected system operations. The Wi-Fi/Bluetooth buttons open the corresponding Android settings pages; they do not silently toggle radios.
- The document picker grants access only to files/folders the user selects. It does not get unrestricted access to the phone's storage.
- Android version and device manufacturer can affect launcher selection, package visibility and settings screens.
- The visual game store entries in the demo remain mock/demo items; they do not download real PC games.
