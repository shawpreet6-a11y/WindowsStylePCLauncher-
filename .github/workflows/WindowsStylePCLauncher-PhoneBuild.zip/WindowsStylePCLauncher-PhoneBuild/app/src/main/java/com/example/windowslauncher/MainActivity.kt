package com.example.windowslauncher

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val filePickerCode = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(LauncherBridge(), "AndroidBridge")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class LauncherBridge {
        @JavascriptInterface fun getApps(): String {
            val result = JSONArray()
            val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
            val matches = packageManager.queryIntentActivities(intent, 0)
                .filter { it.activityInfo.packageName != packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
            for (info in matches) {
                val item = JSONObject()
                item.put("label", info.loadLabel(packageManager).toString())
                item.put("packageName", info.activityInfo.packageName)
                item.put("icon", "📱")
                result.put(item)
            }
            return result.toString()
        }

        @JavascriptInterface fun launchApp(packageName: String) {
            runOnUiThread {
                val launch = packageManager.getLaunchIntentForPackage(packageName)
                if (launch != null) startActivity(launch)
            }
        }

        @JavascriptInterface fun openSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }

        @JavascriptInterface fun openWifiSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
        }

        @JavascriptInterface fun openBluetoothSettings() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        }

        @JavascriptInterface fun openFiles() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, filePickerCode)
            }
        }

        @JavascriptInterface fun getBatteryPercent(): Int {
            val manager = getSystemService(BATTERY_SERVICE) as BatteryManager
            return manager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        }
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == filePickerCode && resultCode == RESULT_OK) {
            data?.data?.let { uri: Uri ->
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }

    override fun onBackPressed() {
        web.evaluateJavascript("closeMenus();", null)
    }
}
